import os, json, time, argparse
from typing import List, Dict, Any
from tools.pagecount import get_page_count
from tools.extract import extract_table
from tools.normalize import normalize_shipto, ensure_numeric, apply_patches

STATES = ["INTAKE","TRIAGE","PARSE","VALIDATE","MERGE","PUBLISH"]

def load_schema(path: str) -> dict:
    with open(path) as f:
        return json.load(f)

def log(line: str, log_path: str):
    with open(log_path, "a") as f:
        f.write(line+"\n")
    print(line)

def decide_single_or_multi(pdf_path: str) -> str:
    pages = get_page_count(pdf_path)
    return "Single" if pages == 1 else "Multi"

def normalize_row(base: Dict[str,Any], raw: Dict[str,Any], cfg_dir: str) -> Dict[str,Any]:
    row = {**base}
    row.update({
        "part_number": raw.get("part_number"),
        "description": raw.get("description"),
        "uom": raw.get("uom") or "Case500E",
        "qty_ordered": ensure_numeric(raw.get("qty_ordered")),
        "unit_price": ensure_numeric(raw.get("unit_price")),
        "line_extension": ensure_numeric(raw.get("line_extension")),
        "notes": raw.get("notes", []),
        "page": raw.get("page", 1)
    })
    row = apply_patches(row, cfg_dir)
    return row

def state_machine(run_id: str, input_dir: str, parsed_dir: str, out_dir: str, log_dir: str, cfg_dir: str, schema_path: str):
    os.makedirs(parsed_dir, exist_ok=True)
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(log_dir, exist_ok=True)
    changelog_path = os.path.join(os.path.dirname(out_dir), "CHANGELOG.md")
    run_log = os.path.join(log_dir, f"{run_id}.log")

    schema = load_schema(schema_path)

    # INTAKE
    files = [os.path.join(input_dir, f) for f in os.listdir(input_dir) if f.lower().endswith('.pdf')]
    log(f"[INTAKE] {len(files)} pdf(s) queued for {run_id}", run_log)

    all_rows: List[Dict[str,Any]] = []
    val_issues = []

    for pdf in files:
        po_number = os.path.splitext(os.path.basename(pdf))[0].replace('Purchase+Order+-+','')
        ship_to_guess = normalize_shipto(open(pdf, 'rb').name, cfg_dir)  # placeholder: use file name/hints
        base = {
            "run_id": run_id,
            "schema_version": schema.get("schema_version"),
            "po_number": po_number,
            "order_date": "",
            "delivery_date": "",
            "vendor_name": "Phoenix Graphics, Inc.",
            "vendor_address": "1525 Emerson St., Rochester, NY 14606",
            "ship_to_name": ship_to_guess,
            "ship_to_address": "",
            "terms": "Net45",
            "ship_via": "TBD",
            "freight_terms": "FOB Origin, Freight Collect",
            "alt_contact_name": "",
            "alt_contact_email": "",
            "receiving_hours": "",
            "plant": ship_to_guess,
            "source_pdf": os.path.basename(pdf)
        }

        # TRIAGE
        mode = decide_single_or_multi(pdf)
        log(f"[TRIAGE] {os.path.basename(pdf)} → Parser:{mode}", run_log)

        # PARSE
        raw_rows = extract_table(pdf)  # replace stub
        log(f"[PARSE] extracted {len(raw_rows)} rows from {os.path.basename(pdf)}", run_log)

        # VALIDATE + NORMALIZE
        for rr in raw_rows:
            row = normalize_row(base, rr, cfg_dir)
            # required checks
            missing = [f for f in schema["required"] if not row.get(f) and row.get(f) != 0]
            if missing:
                val_issues.append({"pdf": os.path.basename(pdf), "missing": missing, "row": rr})
            all_rows.append(row)

        # Emit per-file artifact
        jpath = os.path.join(parsed_dir, f"rows_{run_id}_{po_number}.jsonl")
        with open(jpath, "w") as jf:
            for r in all_rows:
                jf.write(json.dumps(r)+"\n")

    # MERGE
    import pandas as pd
    df = pd.DataFrame(all_rows)
    if not df.empty:
        # Drop price fields in final CSV
        for col in ["unit_price","line_extension"]:
            if col in df.columns:
                df = df.drop(columns=[col])
        csv_path = os.path.join(out_dir, f"combined_{run_id}.csv")
        df.to_csv(csv_path, index=False)
        log(f"[PUBLISH] wrote {csv_path} ({len(df)} rows)", run_log)

        # CHANGELOG
        entry = f"""
## {run_id}
- Files: {len(files)}
- Rows: {len(df)}
- Output: {os.path.basename(csv_path)}
- Validation: {len(val_issues)} issue(s)
"""
        with open(changelog_path, "a") as ch:
            ch.write(entry)
    else:
        log("[PUBLISH] no rows to publish (parser stub)", run_log)
