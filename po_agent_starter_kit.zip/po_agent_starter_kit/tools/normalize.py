import re, json, os
from typing import Dict, Any, List

def load_plant_map(cfg_dir: str) -> dict:
    with open(os.path.join(cfg_dir, "plant_map.json")) as f:
        return json.load(f)

def normalize_shipto(text: str, cfg_dir: str) -> str:
    data = load_plant_map(cfg_dir)
    text_low = (text or "").lower()
    for name in data["canonical"]:
        if name.lower() in text_low:
            return name
    for name, hints in data.get("hints", {}).items():
        if any(h.lower() in text_low for h in hints):
            return name
    return "Unknown"

def clean_description(desc: str) -> str:
    # collapse whitespace; preserve prefixes like (HF; ...)
    return re.sub(r"\s+"," ",(desc or "")).strip()

def ensure_numeric(v):
    try:
        return float(str(v).replace(",",""))
    except Exception:
        return None

def apply_patches(row: Dict[str,Any], cfg_dir: str) -> Dict[str,Any]:
    # simple example using description + uom patch
    patches_path = os.path.join(cfg_dir, "patches.json")
    with open(patches_path) as f:
        data = json.load(f)
    for rule in data.get("rules", []):
        if rule["id"] == "PATCH-DESC-001" and row.get("description"):
            row["description"] = clean_description(row["description"])
        if rule["id"] == "PATCH-UOM-001" and row.get("uom"):
            m = rule.get("map", {})
            key = str(row["uom"]).replace(" ","")
            row["uom"] = m.get(key, row["uom"])
    return row
