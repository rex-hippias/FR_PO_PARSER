# Placeholder extraction — replace with your real parser.
# Return a list of dict rows: part_number, description, uom, qty_ordered, unit_price, line_extension, page
# For now, we emit an empty list and let the pipeline proceed (for wiring tests).
def extract_table(path: str) -> list[dict]:
    return []
