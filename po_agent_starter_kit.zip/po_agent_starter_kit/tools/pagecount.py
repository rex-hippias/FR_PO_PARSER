import pdfplumber

def get_page_count(path: str) -> int:
    try:
        with pdfplumber.open(path) as pdf:
            return len(pdf.pages)
    except Exception:
        # unreadable → force QA/Multi
        return 2
