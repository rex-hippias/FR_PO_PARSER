# PO Agent Starter Kit (Batch Orchestrator → Parser → Output)

This starter kit implements the **Step K** plan we discussed: a small agent with a state machine,
tool functions, and a shared schema. It runs locally on a folder of PDFs and emits normalized
CSV + a cumulative `CHANGELOG.md` — mirroring the threaded workflow you used in ChatGPT.

## What it does (today)
- Creates a RUN-ID (e.g., `RUN-20250926-1200-demo`)
- Scans `/input` for PDFs and decides **Single vs. Multi** via page count
- Extracts a fake table via a placeholder routine (`extract_table()`) — **replace with your real parser**
- Normalizes fields (Ship-To canonicalization, numeric cleanup, description trimming)
- Writes rows as JSONL per parser and merges into a combined CSV per run
- Appends a `CHANGELOG.md` entry

> ⚠️ The extraction function is a **stub**. Swap in your preferred parser (e.g., Ollama/LLM, Tabula,
Tesseract, pdfplumber, Unstructured). The rest (state machine, schema, normalization, outputs) is production-ready.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Put some PDFs into input/
python run_agent.py --run-id RUN-20250926-1200-demo
# Outputs land in output/ and logs/ + CHANGELOG.md
```

## Structure
```
po_agent_starter_kit/
├─ run_agent.py               # CLI entry — orchestrates the state machine
├─ agent.py                   # State machine & orchestration
├─ schema.json                # Shared normalized row schema
├─ requirements.txt
├─ tools/
│  ├─ pagecount.py            # get_page_count(file)
│  ├─ extract.py              # extract_table(file)  ← replace this stub
│  ├─ normalize.py            # normalize_shipto, clean_numbers, etc.
├─ config/
│  ├─ plant_map.json          # canonical plant names + hints
│  └─ patches.json            # regex/rule patches, versioned
├─ input/                     # drop PDFs here
├─ output/                    # combined CSV per run
├─ parsed/                    # rows_<RUN>.jsonl artifacts
├─ logs/                      # simple run log
└─ CHANGELOG.md               # cumulative changes
```

## Swapping in your real parser
In `tools/extract.py`, replace `extract_table_stub()` with your actual extraction. Provide rows with:
`part_number, description, uom, qty_ordered, unit_price, line_extension, page`.

## n8n integration (next step)
- Use an **Email** or **Dropbox** trigger → write files to `/input`
- Add an **Execute Command** node: `python run_agent.py --run-id RUN-<timestamp>-auto`
- On success, upload `/output/combined_<RUN>.csv` to Airtable/S3 and post to Slack
- Optional: post `CHANGELOG.md` diff to a channel

Enjoy! — This kit mirrors your four-thread design while being agent-ready.
