# app.py
from fastapi import FastAPI
from pydantic import BaseModel
import subprocess, uuid, os, requests, shutil

app = FastAPI()

class RunBody(BaseModel):
    run_id: str | None = None
    input_urls: list[str]  # Dropbox direct download links
    output_prefix: str | None = None  # future use (S3, etc.)

@app.post("/runs")
def start_run(body: RunBody):
    run_id = body.run_id or f"RUN-{uuid.uuid4().hex[:8]}"
    workdir = f"/tmp/{run_id}"
    os.makedirs(f"{workdir}/input", exist_ok=True)

    # Download PDFs
    for url in body.input_urls:
        fn = url.split("/")[-1].split("?")[0]
        fp = f"{workdir}/input/{fn}"
        r = requests.get(url, stream=True)
        r.raise_for_status()
        with open(fp, "wb") as f: shutil.copyfileobj(r.raw, f)

    # Run the agent
    subprocess.check_call([
        "python", "run_agent.py", "--run-id", run_id,
        "--input", f"{workdir}/input",
        "--parsed", f"{workdir}/parsed",
        "--output", f"{workdir}/output",
        "--logs", f"{workdir}/logs"
    ])

    combined = f"{workdir}/output/combined_{run_id}.csv"
    changelog = f"{workdir}/CHANGELOG.md"

    return {
        "run_id": run_id,
        "outputs": {
            "combined_csv": combined,
            "changelog": changelog
        }
    }