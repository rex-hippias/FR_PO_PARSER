import argparse, os
from agent import state_machine

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--run-id', required=True)
    p.add_argument('--input', default='input')
    p.add_argument('--parsed', default='parsed')
    p.add_argument('--output', default='output')
    p.add_argument('--logs', default='logs')
    p.add_argument('--config', default='config')
    p.add_argument('--schema', default='schema.json')
    args = p.parse_args()

    # ensure dirs exist
    for d in [args.input, args.parsed, args.output, args.logs]:
        os.makedirs(d, exist_ok=True)

    state_machine(args.run_id, args.input, args.parsed, args.output, args.logs, args.config, args.schema)

if __name__ == '__main__':
    main()
